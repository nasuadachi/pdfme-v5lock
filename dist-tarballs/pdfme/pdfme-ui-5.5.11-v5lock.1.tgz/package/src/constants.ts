export const DEFAULT_LANG = 'en';

export const DESTROYED_ERR_MSG = '[@pdfme/ui] this instance is already destroyed';

export const SELECTABLE_CLASSNAME = 'selectable';

export const RULER_HEIGHT = 30;

export const PAGE_GAP = 10;

export const LEFT_SIDEBAR_WIDTH = 45;

export const RIGHT_SIDEBAR_WIDTH = 400;

export const BACKGROUND_COLOR = 'rgb(74, 74, 74)';

export const DEFAULT_MAX_ZOOM = 2;

export const DESIGNER_CLASSNAME = 'pdfme-designer-';

export const UI_CLASSNAME = 'pdfme-ui-';
