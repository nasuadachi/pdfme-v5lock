export const PDFME_VERSION = '6.1.2';
